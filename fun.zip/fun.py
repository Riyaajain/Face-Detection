import cv2
import face_recognition
import numpy as np
import os

# Paths to store the reference encoding and image
REFERENCE_ENCODING_FILE = "reference_encoding.npy"
REFERENCE_IMAGE_FILE ="D:\papa.jpg"

def capture_reference_image():
    """Capture a reference image for authentication."""
    print("Please look at the camera to capture your face for reference.")
    cap = cv2.VideoCapture(0)

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            print("Error: Unable to access the webcam.")
            break

        cv2.imshow("Reference Capture - Press 's' to Save or 'q' to Quit", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('s'):  # Save reference image
            cap.release()
            cv2.destroyAllWindows()
            return frame
        elif key == ord('q'):  # Quit without saving
            cap.release()
            cv2.destroyAllWindows()
            return None

    cap.release()
    cv2.destroyAllWindows()
    return None

def save_reference_data(encoding, image):
    """Save the reference face encoding and image to files."""
    np.save(REFERENCE_ENCODING_FILE, encoding)  # Save the encoding as a NumPy file
    cv2.imwrite(REFERENCE_IMAGE_FILE, image)  # Save the reference image
    print("Reference face encoding and image saved successfully.")


def load_reference_data():
    """Load the reference face encoding and image from files."""
    if os.path.exists(REFERENCE_ENCODING_FILE) and os.path.exists(REFERENCE_IMAGE_FILE):
        encoding = np.load(REFERENCE_ENCODING_FILE)  # Load the NumPy file
        image = cv2.imread(REFERENCE_IMAGE_FILE)  # Load the reference image
        return encoding, image
    return None, None


def main():
    try:
        # Step 1: Load or capture reference data
        reference_encoding, reference_image = load_reference_data()

        if reference_encoding is None or reference_image is None:
            print("No reference face found. Capturing a new reference face.")
            reference_image = capture_reference_image()
            if reference_image is None:
                print("No reference image captured. Exiting.")
                return

            # Encode the reference face
            reference_image_rgb = cv2.cvtColor(reference_image, cv2.COLOR_BGR2RGB)
            reference_face_encodings = face_recognition.face_encodings(reference_image_rgb)

            if len(reference_face_encodings) == 0:
                print("Error: No face detected in the reference image.")
                return

            reference_encoding = reference_face_encodings[0]
            save_reference_data(reference_encoding, reference_image)
        else:
            print("Referenced Image loaded successfully.")

        # Step 2: Start webcam for live authentication
        print("Starting face authentication...")
        cap = cv2.VideoCapture(0)

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                print("Error: Unable to access the webcam.")
                break

            # Convert the frame to RGB and detect faces
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            face_locations = face_recognition.face_locations(frame_rgb)
            face_encodings = face_recognition.face_encodings(frame_rgb, face_locations)

            for face_encoding, face_location in zip(face_encodings, face_locations):
                # Compare the detected face with the reference face
                matches = face_recognition.compare_faces([reference_encoding], face_encoding, tolerance=0.5)
                face_distance = face_recognition.face_distance([reference_encoding], face_encoding)[0]

                top, right, bottom, left = face_location

                if matches[0]:
                    # Add "Face Recognized" message
                    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
                    cv2.putText(
                        frame, "Face Recognized",
                        (left, bottom + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2
                    )
                    cv2.putText(
                        frame, f"Unlocked (Dist: {face_distance:.2f})",
                        (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2
                    )
                else:
                    cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
                    cv2.putText(
                        frame, "Locked",
                        (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2
                    )

            cv2.imshow("Face Lock Authentication", frame)

            # Press 'q' to quit
            if cv2.waitKey(1) & 0xFF == ord('q'):
                print("Authentication ended by the user.")
                break

        cap.release()
        cv2.destroyAllWindows()

    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()